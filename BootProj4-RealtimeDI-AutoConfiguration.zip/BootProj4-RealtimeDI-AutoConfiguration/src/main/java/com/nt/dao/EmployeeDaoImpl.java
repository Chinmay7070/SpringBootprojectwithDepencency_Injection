package com.nt.dao;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nt.bo.EmployeeBo;

@Repository("empDAO")
public class EmployeeDaoImpl implements IEmployeedao {
	private static final String GET_EMP_BY_DEGS  = "SELECT EMPNO,ENAME,JOB,DAL,DEPTNO,MGR FROM EMP WHERE JOB IN";
    @Autowired
	private DataSource ds;
	public List<EmployeeBo> getEmpsByDesg(String cond) throws Exception {
		List<EmployeeBo> listBO = null;
		try(Connection con1 = ds.getConnection();
			Statement st = con1.createStatement();) {
			ResultSet rs = st.executeQuery(GET_EMP_BY_DEGS+cond+"ORGER BY JOB");
			listBO = new ArrayList();
			EmployeeBo bo = null;
			while(rs.next()) {
				bo = new EmployeeBo();
				bo.setEmpNO(rs.getInt(1));
				bo.setEname(rs.getString(2));
				bo.setJob(rs.getString(3));
				bo.setSal(rs.getDouble(4));
				bo.setDeptNo(rs.getInt(5));
				bo.setMgrNo(rs.getInt(6));
				listBO.add(bo);
			}
		}catch(SQLException se)
		{
			se.printStackTrace();
			throw se;
		}
		catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
		return listBO;
	}

}
