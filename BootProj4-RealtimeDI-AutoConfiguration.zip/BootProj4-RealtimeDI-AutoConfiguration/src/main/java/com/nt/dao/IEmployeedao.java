package com.nt.dao;

import java.util.List;

import com.nt.bo.EmployeeBo;

public interface IEmployeedao {
	public List<EmployeeBo> getEmpsByDesg(String con)throws Exception;
	

}
