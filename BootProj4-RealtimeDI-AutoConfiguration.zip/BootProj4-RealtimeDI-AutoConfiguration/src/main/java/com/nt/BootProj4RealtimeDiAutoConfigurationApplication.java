package com.nt;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootProj4RealtimeDiAutoConfigurationApplication {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in) ;
			System.out.println("Desgs count");
			int count = sc.nextInt();
			String desgs[] = null;
			if(count>=1) {
				desgs = new String[count];
			}else {
				System.out.println("INVALID DESG COUNT");
				return;
			}
			for(int i=0;i<count;i++) {
				System.out.println("Enter desg"+(i+1));
				
			}
		
		SpringApplication.run(BootProj4RealtimeDiAutoConfigurationApplication.class, args);
	}

}
