package com.nt.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class Employeevo{
	    private String srNo;
		private String empNo;
		private String ename;
		private String job;
		private String sal;
		private String deptNo;
		private String mgrNo;	

}
