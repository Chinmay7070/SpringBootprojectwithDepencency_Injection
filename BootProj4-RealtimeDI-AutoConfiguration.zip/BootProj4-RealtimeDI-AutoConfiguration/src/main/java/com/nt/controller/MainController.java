package com.nt.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.nt.Service.IEmployeeManagementService;
import com.nt.dto.EmployeeDTO;
import com.nt.vo.Employeevo;

@Controller("controller")
public class MainController {
 @Autowired
 private IEmployeeManagementService service;
 
 public List<Employeevo> ShowEmpsbyDesgs(String degs[])throws Exception{
	 
	 List<EmployeeDTO> listdto = service.FetchEmpsByDesgs(degs);
	 List<Employeevo> listvo = new ArrayList();
	 listdto.forEach(dto->{
		 Employeevo vo = new Employeevo();
		 BeanUtils.copyProperties(dto,vo);
		 vo.setSrNo(String.valueOf(dto.getSrNo()));
		 vo.setEmpNo(String.valueOf(dto.getEmpNo()));
			vo.setSal(String.valueOf(dto.getSal()));
			vo.setDeptNo(String.valueOf(dto.getDeptNo()));
			vo.setMgrNo(String.valueOf(dto.getMgrNo()));
			listvo.add(vo);
	 });
	 return listvo;
	 
 }
 
}
