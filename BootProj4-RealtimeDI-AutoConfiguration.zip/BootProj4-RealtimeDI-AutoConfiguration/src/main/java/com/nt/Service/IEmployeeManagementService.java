package com.nt.Service;

import java.util.List;

import com.nt.dto.EmployeeDTO;

public interface IEmployeeManagementService {
	public List<EmployeeDTO> FetchEmpsByDesgs(String desg[])throws Exception;

}
