package com.nt.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.bo.EmployeeBo;
import com.nt.dao.IEmployeedao;
import com.nt.dto.EmployeeDTO;
@Service("empService")
public class EmployeemgtService implements IEmployeeManagementService {
    @Autowired
	private IEmployeedao dao;
	@Override
	public List<EmployeeDTO> FetchEmpsByDesgs(String[] desg) throws Exception {
		
		StringBuffer buffer = new StringBuffer("(");
		for(int i=0;i<desg.length;i++) {
			if(i==desg.length-1) {
				buffer.append("'"+desg[i]+"')");
			}
			else {
				buffer.append("'"+desg[i]+"',");
			}
		}
		String cond1 = buffer.toString(); 
		List<EmployeeBo> listBO = dao.getEmpsByDesg(cond1);
		   
		List<EmployeeDTO> listDto = new ArrayList();
		listBO.forEach(bo->{
			EmployeeDTO dto = new EmployeeDTO();
			BeanUtils.copyProperties(bo,dto);
			dto.setSrNo(listDto.size()+1);
			listDto.add(dto);
			
		});
		return listDto;
	}

}
