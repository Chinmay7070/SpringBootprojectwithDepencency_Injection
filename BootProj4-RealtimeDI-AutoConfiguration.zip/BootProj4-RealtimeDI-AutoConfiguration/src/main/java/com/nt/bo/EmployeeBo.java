package com.nt.bo;

import lombok.Data;

@Data
public class EmployeeBo {
	private Integer empNO;
	private String ename;
	private String job;
	private Double sal;
	private Integer deptNo;
	private Integer mgrNo;
	

}
